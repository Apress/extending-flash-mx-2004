
Convert All To Clips v1.0
written 2004 by Sascha Balkau
sascha@hiddenresource.corewatch.net
http://hiddenresource.corewatch.net/


1. What does it do?

Another time saving helper! Imagine you got tons of bitmaps to be imported into your Flash project and to convert them all to symbols. You would have to go like put them all on the stage and one by one convert them to symbols by pressing F8, eventually set the name and registration point. If you had such situations you know that it's a very cumbersome task. CATC is able to do the job for you within some seconds!


2. Features

- Can convert a selection of items in the library to symbols, either movie clips, buttons or graphic symbols.
- The registration point can be set.
- A name prefix can be set.
- Leading zeroes can be used to keep the correct order of the items after conversion.
- Name of the destination folder can be set.


3. Limitations

The correct item order of the selection can only be maintained if the selected items are named in an ordered naming convention! E.g. if you got items which are named item_01, item_02, item_03, item_04 etc., CATC will maintain the order. If you got something like item_44, item_45, item_100, item_101 etc. the original order will be changed so that the items which start with 1 will be placed first. This seems to be a limitation of the JSFL library getSelectedItems array. At least I haven't found a workaround for this yet.

