
Flash Library Items Renamer V1.2
written 2004 by Sascha Balkau
sascha@hiddenresource.corewatch.net
http://hiddenresource.corewatch.net/


1. What does it do?

Imagine you got a big amount of items in your library and all have to be renamed, exported for actionscript and given a linked class name. This can turn out to be very tedious so this is the part where Library Items Renamer can make your life easier.


2. Features

- Can rename a selection of files in the library to have a new name and a number suffix. For example clip_1, clip_2, clip_3 ...
- You are able to only use numbers as names.
- By default numbers start at zero but you can set the suffix number to any beginning value you like.
- Leading zeroes can be used. They are supported up to 4 digits long values.
- Exporting for ActionScript can be toggled on/off.
- Export into first frame can be toggled on/off.
- AS2.0 Linkage Class Name can be set (and removed).
- Renamed items can be moved to a new folder.
- Leaving the Name field empty will only change the other settings, not the Name.
- Items can be updated.
- Export- and Class-settings only affect items of the type 'movie clip', 'graphic', 'button', 'font', 'sound' and 'component', while 'bitmaps', 'videos' and 'compiled clips' still can be renamed/moved/updated.


3. Version History

1.2:
- Items can now be updated automatically (e.g. useful for updating bitmaps).
- Changed the script so that all item types can be used with it (export/class settings doesn't affect bitmaps, video and compiled clips).

1.1:
- Toggling Export for ActionScript on/off works now.
- Renamed items can be moved to a new folder. A folder name can be given.
- Leaving the name field empty will only change the other settings, like export, AS 2.0 Class etc.
- Some other minor improvments.


4. Limitations and Bugs

- Folders will not be renamed but it's better to not even select them as then the numbering can get messed up.
- In some occasions Flash will complain if an item name is existing already. In that case just rename the whole selection to something else and then rename to what you wanted before.
