Spiral  v 1.0.0

The Spiral tool allows to draw spirals. The mouseDown event determines the center of the spiral. 
If you switch on Manual radius, Manual length, and manual acceleration, you can change these parameters of the spiral on mouseMove. The angle of the mouse's rotation around the center determines the acceleration of the spiral, the distance between the center and the mouse position determines the length of the spiral. Pressing on key Down or Key Up increases or decreases the inner radius of the spiral. 
But you can unswitch manual option and enter the values in the option panel. 

The options:

length: 1 to 500 : the number of circles of the spiral. That determines the length of the spiral. Default value : 50. 

manual length: boolean - Default value : true. 

acceleration: 1 to 5 : determines the way the spiral opens it self. if the acceleration is 1.01, the circles are very tight. if it's 5, it's a quite wide spiral. Default value : 1.10

manuel acceleration: boolean - Default value : true. 

inner radius: 0.1 to 50 :determines the inner radius of the spiral. 1 is the default value.

manuel radius: boolean - Default value : true. 

rotation: -180 to 180 : rotates the spiral around it's center. Default value : 0

Millie Maruani
millie@noos.fr
http://millie.free.fr
