Ok I have finished my first extension. Thanks to all how answered my questions over the last couple of days. It's a little more difficult when you don't have the docs. 

Anyways it's a Library Item Updater. In the panel found under Other Panels you can, select Multiple files, type in a Library Item and hit start.

It will then open the documents, update the library item, save, publish and close.

I still want to add a few more features like a enable/disable publish button and clear all button. 

If anyone has any other ideas let me know. I'd love to here them. Let me know how it works out for you.