Dots Spiral  v 1.0.1

The Dots Spiral tool allows to draw spirals in one click, centered on the mouseUp point. It's not a conventional tool with mouseDown and mouseMove method. Take care you don't click ten times, you'll have to wait for ten spirals to be drawn. I hope i'll fix that in a second version. if you want a very smooth circular spiral you must add dots, that means adding lines and using more CPU.
You could use the Spiral tool in this case, drawn with quarter of circles, approximated by bezier curves. 

The options:

points: 3 to 250 : the number of points in one circle of the spiral. with 50 dots, the spiral is quite cicular. it's the default value. you can have one more smooth with 250 points. i didn't allow more as that requires a lot of CPU. With three point you have a triangular spiral, 4 points a square spiral, 5 points, a star shape spiral... etc. Default value : 8

circles: 1 to 100 : the number of circles. that determines the length of the spiral. Default value : 10. don't try too many circles with too many points!... 

acceleration: 1 to 5 : determines the way the spiral opens it self. if the acceleration is 1, the circles are quasi equidistant. if it's 5, it's a very wide spiral. Default value : 1

inner radius: 0.1 to 50 :determines the distance between the circles. 1 is the default value.

rotation: -180 to 180 : rotates the spiral around it's center. Default value : 0

Millie Maruani
millie@noos.fr
http://millie.free.fr
